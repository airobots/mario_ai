__author__="Sergey Karakovskiy, sergey at idsia fullstop ch"
__date__ ="$May 13, 2009 12:15:50 AM$"

from experiment import Experiment
from episodicexperiment import EpisodicExperiment

