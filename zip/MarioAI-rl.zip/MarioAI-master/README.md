# MarioAI
A Reinforcement Learning agent for Mario
